# Finapse X executor
Allows you to run code in Webfishing via Finapse X